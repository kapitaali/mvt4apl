/* ------------------------------------------------------------------------- */
/* Set TERMINFO value to the value given by configure */
#undef RXVT_TERMINFO

/* Set TERM to the value given by configure */
#undef TERMENV

/* Define if you want KANJI support */
/* after compilation, rename executable as `kxvt' */
#undef KANJI

/* Define if you want BIG5 support */
/* after compilation, rename executable as `crxvt' */
#undef BIG5

/* Define if Xlocale support doesn't work */
#undef NO_XLOCALE

/* Define if you want Menubar support */
#undef MENUBAR

/* Define if you want Rob Nation's own graphic mode */
#undef RXVT_GRAPHICS

/* Define if you want to revert to Xterm style scrollbars */
#undef XTERM_SCROLLBAR

/* Define if you want support for Greek Elot-928 & IBM-437 keyboard */
/* see doc/README.greek */
#undef GREEK_SUPPORT

/* Define if you want tty's to be setgid() to the `tty' group */
#undef TTY_GID_SUPPORT

/* Define if you want to have utmp/utmpx support */
#undef UTMP_SUPPORT

/* Define if you want to have wtmp support when utmp/utmpx is enabled */
#undef WTMP_SUPPORT

/* Define if you want to have sexy-looking background pixmaps. Needs libXpm */
#undef XPM_BACKGROUND

/* Define if you include <X11/xpm.h> on a normal include path (be careful) */
#undef XPM_INC_X11
/* ------------------------------------------------------------------------- */
/* Define if struct utmp/utmpx contains ut_host */
#undef HAVE_UTMP_HOST

/* Define location of utmp/utmpx */
#undef RXVT_UTMP_FILE

/* Define location of wtmp */
#undef RXVT_WTMP_FILE

/* Define location of ttys/ttytab */
#undef TTYTAB_FILENAME

/* Define if you need function prototypes */
#undef PROTOTYPES

