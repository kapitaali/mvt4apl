/* Include prototypes for all files */
/*
 * $Date: Sun, 03 Aug 1997 16:47:17 +0000 $
 */
#include "command.pro"
#ifdef RXVT_GRAPHICS
#include "graphics.pro"
#endif
#include "grkelot.pro"
#include "main.pro"
#include "menubar.pro"
#include "misc.pro"
#include "netdisp.pro"
#include "rmemset.pro"
#include "screen.pro"
#include "scrollbar.pro"
#ifdef UTMP_SUPPORT
#include "utmp.pro"
#endif
#include "xdefaults.pro"
