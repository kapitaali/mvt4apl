#define VERSION "2.4.5"
#define DATE	"1 JANUARY 1998"
#define LSMDATE	"01JAN98"
